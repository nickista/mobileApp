package com.example.hyojason;

import java.io.Serializable;
import java.util.List;

public class Medicine implements Serializable {
    private String name;
    private String dosage;
    private List<String> times; // "08:00", "12:00", "18:00" 형태
    private List<String> days; // "월", "화", "수" 등
    private String startDate;
    private String endDate;
    private boolean isCompleted;
    private long id;

    public Medicine() {
        this.id = System.currentTimeMillis();
    }

    public Medicine(String name, String dosage, List<String> times, List<String> days,
                    String startDate, String endDate) {
        this.name = name;
        this.dosage = dosage;
        this.times = times;
        this.days = days;
        this.startDate = startDate;
        this.endDate = endDate;
        this.isCompleted = false;
        this.id = System.currentTimeMillis();
    }

    // Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDosage() { return dosage; }
    public void setDosage(String dosage) { this.dosage = dosage; }

    public List<String> getTimes() { return times; }
    public void setTimes(List<String> times) { this.times = times; }

    public List<String> getDays() { return days; }
    public void setDays(List<String> days) { this.days = days; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    public boolean isCompleted() { return isCompleted; }
    public void setCompleted(boolean completed) { isCompleted = completed; }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
}