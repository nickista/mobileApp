package com.example.hyojason;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MedicineManager {

    private static final String PREFS_NAME = "MedicinePrefs";
    private static final String KEY_MEDICINES = "medicines";

    private SharedPreferences prefs;
    private Gson gson;

    public MedicineManager(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    public void addMedicine(Medicine medicine) {
        List<Medicine> medicines = getAllMedicines();
        medicines.add(medicine);
        saveMedicines(medicines);

        // 알림 스케줄링
        scheduleAlarms(medicine);
    }

    public void updateMedicine(Medicine medicine) {
        List<Medicine> medicines = getAllMedicines();
        for (int i = 0; i < medicines.size(); i++) {
            if (medicines.get(i).getId() == medicine.getId()) {
                medicines.set(i, medicine);
                break;
            }
        }
        saveMedicines(medicines);
    }

    public void deleteMedicine(long medicineId) {
        List<Medicine> medicines = getAllMedicines();
        medicines.removeIf(medicine -> medicine.getId() == medicineId);
        saveMedicines(medicines);
    }

    public List<Medicine> getAllMedicines() {
        String json = prefs.getString(KEY_MEDICINES, "[]");
        Type type = new TypeToken<List<Medicine>>(){}.getType();
        return gson.fromJson(json, type);
    }

    public List<Medicine> getTodayMedicines() {
        List<Medicine> allMedicines = getAllMedicines();
        List<Medicine> todayMedicines = new ArrayList<>();

        Calendar today = Calendar.getInstance();
        String todayDay = getDayOfWeek(today.get(Calendar.DAY_OF_WEEK));

        for (Medicine medicine : allMedicines) {
            if (medicine.getDays().contains(todayDay)) {
                // 각 복용 시간별로 별도의 Medicine 객체 생성
                for (String time : medicine.getTimes()) {
                    Medicine dailyMedicine = new Medicine();
                    dailyMedicine.setId(medicine.getId());
                    dailyMedicine.setName(medicine.getName());
                    dailyMedicine.setDosage(medicine.getDosage());
                    dailyMedicine.setTimes(List.of(time));
                    dailyMedicine.setDays(medicine.getDays());
                    dailyMedicine.setCompleted(medicine.isCompleted());

                    todayMedicines.add(dailyMedicine);
                }
            }
        }

        // 시간순으로 정렬
        todayMedicines.sort((m1, m2) -> {
            String time1 = m1.getTimes().get(0);
            String time2 = m2.getTimes().get(0);
            return time1.compareTo(time2);
        });

        return todayMedicines;
    }

    private void saveMedicines(List<Medicine> medicines) {
        String json = gson.toJson(medicines);
        prefs.edit().putString(KEY_MEDICINES, json).apply();
    }

    private String getDayOfWeek(int dayOfWeek) {
        String[] days = {"", "일", "월", "화", "수", "목", "금", "토"};
        return days[dayOfWeek];
    }

    private void scheduleAlarms(Medicine medicine) {
        // TODO: AlarmManager를 사용한 알림 스케줄링 구현
        // 각 복용 시간과 요일에 맞춰 알림 설정
    }
}
