package com.example.hyojason;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "MedicineReminderChannel";
    private static final int NOTIFICATION_ID = 1001;

    @Override
    public void onReceive(Context context, Intent intent) {
        String medicineName = intent.getStringExtra("medicine_name");
        String dosage = intent.getStringExtra("dosage");
        String time = intent.getStringExtra("time");

        if (medicineName != null) {
            showNotification(context, medicineName, dosage, time);
        }
    }

    private void showNotification(Context context, String medicineName, String dosage, String time) {
        NotificationManager notificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Android 8.0 이상에서 알림 채널 생성
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "약 복용 알림",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("약 복용 시간을 알려드립니다");
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            notificationManager.createNotificationChannel(channel);
        }

        // 메인 액티비티로 이동하는 인텐트
        Intent mainIntent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 0, mainIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // 알림 생성
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("💊 약 복용 시간입니다!")
                .setContentText(medicineName + " " + dosage + " (" + time + ")")
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText(medicineName + " " + dosage + "을(를) 복용하실 시간입니다.\n시간: " + time))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setVibrate(new long[]{0, 1000, 500, 1000})
                .setContentIntent(pendingIntent)
                .addAction(android.R.drawable.ic_menu_view, "확인", pendingIntent);

        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }
}
