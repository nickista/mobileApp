package com.example.hyojason;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MedicineAdapter extends RecyclerView.Adapter<MedicineAdapter.ViewHolder> {

    private List<Medicine> medicines;
    private OnMedicineClickListener listener;

    public interface OnMedicineClickListener {
        void onCheckboxClicked(Medicine medicine, boolean isChecked);
    }

    public MedicineAdapter(List<Medicine> medicines, OnMedicineClickListener listener) {
        this.medicines = medicines;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_medicine, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Medicine medicine = medicines.get(position);
        holder.bind(medicine);
    }

    @Override
    public int getItemCount() {
        return medicines.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tvTime, tvPeriod, tvMedicineName, tvDosage;
        private CheckBox cbCompleted;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTime = itemView.findViewById(R.id.tv_time);
            tvPeriod = itemView.findViewById(R.id.tv_period);
            tvMedicineName = itemView.findViewById(R.id.tv_medicine_name);
            tvDosage = itemView.findViewById(R.id.tv_dosage);
            cbCompleted = itemView.findViewById(R.id.cb_completed);
        }

        public void bind(Medicine medicine) {
            // 첫 번째 복용 시간 표시 (여러 시간이 있을 경우)
            if (!medicine.getTimes().isEmpty()) {
                String time = medicine.getTimes().get(0);
                tvTime.setText(time);
                tvPeriod.setText(getTimePeriod(time));
            }

            tvMedicineName.setText(medicine.getName());
            tvDosage.setText(medicine.getDosage());
            cbCompleted.setChecked(medicine.isCompleted());

            // 체크박스 클릭 리스너
            cbCompleted.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (listener != null) {
                    listener.onCheckboxClicked(medicine, isChecked);
                }
            });
        }

        private String getTimePeriod(String time) {
            if (time == null) return "";

            String[] parts = time.split(":");
            if (parts.length < 2) return "";

            try {
                int hour = Integer.parseInt(parts[0]);
                if (hour >= 5 && hour < 11) return "아침";
                else if (hour >= 11 && hour < 15) return "점심";
                else if (hour >= 15 && hour < 19) return "저녁";
                else return "밤";
            } catch (NumberFormatException e) {
                return "";
            }
        }
    }
}
