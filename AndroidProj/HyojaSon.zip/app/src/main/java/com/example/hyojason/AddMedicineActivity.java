package com.example.hyojason;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class AddMedicineActivity extends AppCompatActivity {

    private static final int VOICE_RECOGNITION_REQUEST = 1001;

    private EditText etMedicineName, etDosage;
    private MaterialButton btnVoiceInput;
    private ChipGroup chipGroupTimes, chipGroupDays;
    private TimePicker timePicker;
    private LinearLayout layoutCustomTime;
    private Button btnSave, btnCancel;
    private MaterialButton btnAddCustomTime;

    private List<String> selectedTimes = new ArrayList<>();
    private List<String> selectedDays = new ArrayList<>();
    private MedicineManager medicineManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_medicine);

        initViews();
        setupTimeChips();
        setupDayChips();
        setupClickListeners();

        medicineManager = new MedicineManager(this);
    }

    private void initViews() {
        etMedicineName = findViewById(R.id.et_medicine_name);
        etDosage = findViewById(R.id.et_dosage);
        btnVoiceInput = findViewById(R.id.btn_voice_input);
        chipGroupTimes = findViewById(R.id.chip_group_times);
        chipGroupDays = findViewById(R.id.chip_group_days);
        timePicker = findViewById(R.id.time_picker);
        layoutCustomTime = findViewById(R.id.layout_custom_time);
        btnSave = findViewById(R.id.btn_save);
        btnCancel = findViewById(R.id.btn_cancel);
        btnAddCustomTime = findViewById(R.id.btn_add_custom_time);
    }

    private void setupTimeChips() {
        String[] times = {"08:00", "12:00", "18:00", "22:00"};
        String[] timeLabels = {"아침 8시", "점심 12시", "저녁 6시", "밤 10시"};

        for (int i = 0; i < times.length; i++) {
            Chip chip = new Chip(this);
            chip.setText(timeLabels[i]);
            chip.setCheckable(true);
            chip.setTag(times[i]);

            chip.setOnCheckedChangeListener((buttonView, isChecked) -> {
                String time = (String) buttonView.getTag();
                if (isChecked) {
                    selectedTimes.add(time);
                } else {
                    selectedTimes.remove(time);
                }
            });

            chipGroupTimes.addView(chip);
        }

        // 사용자 정의 시간 추가 칩
        Chip customChip = new Chip(this);
        customChip.setText("+ 시간 직접 설정");
        customChip.setCheckable(true);
        customChip.setOnCheckedChangeListener((buttonView, isChecked) -> {
            layoutCustomTime.setVisibility(isChecked ? View.VISIBLE : View.GONE);
        });
        chipGroupTimes.addView(customChip);
    }

    private void setupDayChips() {
        String[] days = {"월", "화", "수", "목", "금", "토", "일"};

        for (String day : days) {
            Chip chip = new Chip(this);
            chip.setText(day);
            chip.setCheckable(true);
            chip.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    selectedDays.add(buttonView.getText().toString());
                } else {
                    selectedDays.remove(buttonView.getText().toString());
                }
            });
            chipGroupDays.addView(chip);
        }

        // 매일 선택 칩
        Chip everydayChip = new Chip(this);
        everydayChip.setText("매일");
        everydayChip.setCheckable(true);
        everydayChip.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                selectedDays.clear();
                selectedDays.addAll(Arrays.asList(days));
                // 모든 요일 칩 체크
                for (int i = 0; i < chipGroupDays.getChildCount() - 1; i++) {
                    Chip chip = (Chip) chipGroupDays.getChildAt(i);
                    chip.setChecked(true);
                }
            }
        });
        chipGroupDays.addView(everydayChip);
    }

    private void setupClickListeners() {
        btnVoiceInput.setOnClickListener(v -> startVoiceRecognition());

        btnAddCustomTime.setOnClickListener(v -> {
            int hour = timePicker.getHour();
            int minute = timePicker.getMinute();
            String customTime = String.format(Locale.getDefault(), "%02d:%02d", hour, minute);

            if (!selectedTimes.contains(customTime)) {
                selectedTimes.add(customTime);
                Toast.makeText(this, customTime + " 시간이 추가되었습니다", Toast.LENGTH_SHORT).show();
            }
        });

        btnSave.setOnClickListener(v -> saveMedicine());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void startVoiceRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "음성 인식을 사용할 수 없습니다", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.KOREAN);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "약 이름을 말씀해주세요");

        try {
            startActivityForResult(intent, VOICE_RECOGNITION_REQUEST);
        } catch (Exception e) {
            Toast.makeText(this, "음성 인식을 시작할 수 없습니다", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == VOICE_RECOGNITION_REQUEST && resultCode == RESULT_OK) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                String spokenText = results.get(0);
                etMedicineName.setText(spokenText);
                Toast.makeText(this, "음성 입력: " + spokenText, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void saveMedicine() {
        String name = etMedicineName.getText().toString().trim();
        String dosage = etDosage.getText().toString().trim();

        if (name.isEmpty()) {
            Toast.makeText(this, "약 이름을 입력해주세요", Toast.LENGTH_SHORT).show();
            return;
        }

        if (dosage.isEmpty()) {
            dosage = "1알";
        }

        if (selectedTimes.isEmpty()) {
            Toast.makeText(this, "복용 시간을 선택해주세요", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedDays.isEmpty()) {
            Toast.makeText(this, "복용 요일을 선택해주세요", Toast.LENGTH_SHORT).show();
            return;
        }

        Medicine medicine = new Medicine(name, dosage, selectedTimes, selectedDays, "", "");
        medicineManager.addMedicine(medicine);

        Toast.makeText(this, "약이 등록되었습니다", Toast.LENGTH_SHORT).show();
        finish();
    }
}
