package com.example.hyojason;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MedicineAdapter adapter;
    private List<Medicine> medicineList;
    private TextView tvTodayDate;
    private LinearLayout layoutEmpty;
    private MaterialButton btnAddMedicine;
    private MedicineManager medicineManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupRecyclerView();
        setTodayDate();
        loadMedicines();

        btnAddMedicine.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddMedicineActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadMedicines(); // 약 추가 후 돌아왔을 때 새로고침
    }

    private void initViews() {
        recyclerView = findViewById(R.id.rv_medicines);
        tvTodayDate = findViewById(R.id.tv_today_date);
        layoutEmpty = findViewById(R.id.layout_empty);
        btnAddMedicine = findViewById(R.id.btn_add_medicine);
        medicineManager = new MedicineManager(this);
    }

    private void setupRecyclerView() {
        medicineList = new ArrayList<>();
        adapter = new MedicineAdapter(medicineList, new MedicineAdapter.OnMedicineClickListener() {
            @Override
            public void onCheckboxClicked(Medicine medicine, boolean isChecked) {
                medicine.setCompleted(isChecked);
                medicineManager.updateMedicine(medicine);

                // 알림 표시
                if (isChecked) {
                    // TODO: "복용 완료!" 토스트 메시지 표시
                }
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private void setTodayDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일", Locale.KOREAN);
        String today = sdf.format(new Date());
        tvTodayDate.setText(today);
    }

    private void loadMedicines() {
        medicineList.clear();
        List<Medicine> todayMedicines = medicineManager.getTodayMedicines();
        medicineList.addAll(todayMedicines);

        if (medicineList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            layoutEmpty.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            layoutEmpty.setVisibility(View.GONE);
        }

        adapter.notifyDataSetChanged();
    }
}